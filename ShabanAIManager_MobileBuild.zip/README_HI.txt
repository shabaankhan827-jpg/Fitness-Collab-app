SHABAN AI MANAGER — ANDROID STUDIO PROJECT (DEMO)

ZAROORI BAAT:
Yeh Android app ka source project hai, ready-made APK nahi.
Is environment mein Android SDK/Gradle build tools available nahi the,
isliye yahan signed APK compile nahi kiya gaya.

APK banane ke liye:
1. Computer par Android Studio install karein.
2. Android Studio mein "Open" karke is folder ko select karein.
3. Gradle sync complete hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) par click karein.
5. APK app/build/outputs/apk/debug/ folder mein milega.

APP KI LIMITS:
- Yeh demo UI hai; Instagram account connect nahi hota.
- Brand list sample hai, live verified brand search nahi.
- Analytics placeholder/demo data hai.
- Real Instagram connection ke liye official Meta APIs, app review
  aur user-approved permissions ki zaroorat hogi.
- Apna Instagram password ya OTP kisi third-party app mein mat daalein.
